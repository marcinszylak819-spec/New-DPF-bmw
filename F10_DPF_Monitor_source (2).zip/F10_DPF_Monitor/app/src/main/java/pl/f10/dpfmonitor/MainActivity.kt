package pl.f10.dpfmonitor

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.UUID
import java.io.InputStream
import java.io.OutputStream

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF111824)
private val Cyan = Color(0xFF43E5D0)
private val Blue = Color(0xFF5A8CFF)
private val Muted = Color(0xFF91A0B7)

class MainActivity : ComponentActivity() {
    private val vm = DpfViewModel()
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) connectPairedAdapter() else vm.message = "Brak uprawnień Bluetooth"
    }
    private val bluetoothManager by lazy { getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager }
    private val adapter: BluetoothAdapter? get() = bluetoothManager.adapter
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var input: InputStream? = null
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DpfScreen(vm, onConnect = { requestPermissionsAndScan() }, onDisconnect = { closeSocket() }) }
        // First launch asks for Bluetooth permission and then attempts to reconnect to the paired vLinker.
        requestPermissionsAndScan()
    }

    private fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private fun requestPermissionsAndScan() {
        val missing = requiredPermissions().filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray()) else connectPairedAdapter()
    }

    @SuppressLint("MissingPermission")
    private fun connectPairedAdapter() {
        val a = adapter
        if (a == null || !a.isEnabled) { vm.message = "Włącz Bluetooth w telefonie"; return }
        val device = try {
            a.bondedDevices.firstOrNull { d ->
                val n = d.name ?: ""
                n.contains("vLinker", true) || n.contains("Vgate", true) || n.contains("V-LINK", true) || n.contains("BM-Android", true)
            }
        } catch (_: SecurityException) { null }
        if (device == null) {
            vm.connecting = false
            vm.message = "Nie znaleziono sparowanego vLinker. Sparuj ‘vLinker BM-Android’ w ustawieniach Bluetooth (PIN zwykle 1234), potem spróbuj ponownie."
            return
        }
        closeSocket()
        vm.adapterName = device.name ?: "vLinker BM-Android"
        vm.connecting = true
        vm.message = "Łączę z ${vm.adapterName}…"
        Thread {
            try {
                a.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                socket = s
                s.connect()
                input = s.inputStream
                output = s.outputStream
                output?.write("ATZ\r".toByteArray(Charsets.US_ASCII))
                output?.flush()
                Thread.sleep(900)
                val buffer = ByteArray(512)
                val available = input?.available() ?: 0
                val reply = if (available > 0) { val count = input!!.read(buffer, 0, minOf(buffer.size, available)); String(buffer, 0, count, Charsets.US_ASCII).replace("\r", " ").replace("\n", " ").trim() } else "Adapter nie zwrócił jeszcze identyfikacji ELM"
                runOnUiThread {
                    vm.connected = true
                    vm.connecting = false
                    vm.lastResponse = reply.take(120)
                    vm.message = "Połączono z adapterem Bluetooth. Odczyt statusu DPF z BMW DDE nie jest jeszcze zaimplementowany — połączenie z adapterem nie oznacza odczytu ECU."
                }
            } catch (e: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                socket = null; input = null; output = null
                runOnUiThread { vm.connected = false; vm.connecting = false; vm.message = "Nie udało się połączyć: ${e.message ?: "sprawdź parowanie i czy inna aplikacja nie używa adaptera"}" }
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    private fun closeSocket() {
        try { output?.close() } catch (_: Exception) {}
        try { input?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        output = null; input = null; socket = null
        vm.connected = false; vm.connecting = false; vm.message = "Rozłączono z adapterem"
    }

    override fun onDestroy() { closeSocket(); super.onDestroy() }

}

class DpfViewModel {
    var connected by mutableStateOf(false)
    var connecting by mutableStateOf(false)
    var message by mutableStateOf("Gotowy do połączenia z adapterem")
    var adapterName by mutableStateOf("vLinker BM-Android")
    var lastResponse by mutableStateOf("Brak odpowiedzi ECU")
}

@Composable
fun DpfScreen(vm: DpfViewModel, onConnect: () -> Unit, onDisconnect: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101B2C), Bg, Color(0xFF080B12))))) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("F10  /  DIESEL LAB", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("DPF MONITOR", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                    Box(Modifier.size(46.dp).border(1.dp, Cyan.copy(alpha = .45f), CircleShape).background(Cyan.copy(alpha = .08f), CircleShape), contentAlignment = Alignment.Center) { Text("M", color = Cyan, fontWeight = FontWeight.Black, fontSize = 23.sp) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip(if (vm.connected) "OBD POŁĄCZONE" else if (vm.connecting) "SZUKAM…" else "OBD OFFLINE", if (vm.connected) Cyan else if (vm.connecting) Blue else Color(0xFFFFB454))
                    StatusChip("BMW F10", Color(0xFF8EA7FF))
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = .96f)), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("STATUS REGENERACJI", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                        Spacer(Modifier.height(14.dp))
                        Box(Modifier.size(206.dp), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.fillMaxSize()) {
                                val sw = 13.dp.toPx(); val pad = sw / 2
                                drawArc(Color(0xFF253247), 135f, 270f, false, topLeft = Offset(pad, pad), size = Size(size.width - sw, size.height - sw), style = androidx.compose.ui.graphics.drawscope.Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                                drawArc(Brush.sweepGradient(listOf(Cyan, Blue, Cyan)), 135f, 1f, false, topLeft = Offset(pad, pad), size = Size(size.width - sw, size.height - sw), style = androidx.compose.ui.graphics.drawscope.Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("—", fontSize = 50.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text("BRAK DANYCH", fontSize = 11.sp, color = Color(0xFFFFC16D), fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text("DPF", fontSize = 12.sp, color = Muted)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Status ECU nie został jeszcze potwierdzony", color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Aplikacja nie zgaduje stanu regeneracji. Najpierw połącz adapter i skonfiguruj odczyt sterownika.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard("TEMP. SPALIN", "—", "°C", Modifier.weight(1f))
                    MetricCard("SADZA", "—", "g", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard("CIŚNIENIE DPF", "—", "mbar", Modifier.weight(1f))
                    MetricCard("PRZEBIEG REGEN.", "—", "km", Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("POŁĄCZENIE Z AUTEM", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(vm.message, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                        Text("Adapter: ${vm.adapterName}", color = Color(0xFFCFD8E7), fontSize = 12.sp)
                        Text("Ostatnia odpowiedź: ${vm.lastResponse}", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                        Button(onClick = { if (vm.connected) onDisconnect() else onConnect() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = if (vm.connected) Color(0xFF263449) else Cyan, contentColor = if (vm.connected) Color.White else Color(0xFF061014))) {
                            Text(if (vm.connected) "ROZŁĄCZ ADAPTER" else if (vm.connecting) "SZUKANIE ADAPTERA…" else "POŁĄCZ Z vLINKER", fontWeight = FontWeight.Black, letterSpacing = .8.sp)
                        }
                    }
                }
                Text("PROTOTYP • ODCZYT DPF WYMAGA DOPASOWANIA DO SILNIKA I ECU", color = Muted, fontSize = 9.sp, letterSpacing = .8.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
            }
        }
    }
}

@Composable private fun StatusChip(label: String, tint: Color) {
    Row(Modifier.background(tint.copy(alpha = .1f), RoundedCornerShape(50)).border(1.dp, tint.copy(alpha = .35f), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        Box(Modifier.size(6.dp).background(tint, CircleShape)); Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
    }
}

@Composable private fun MetricCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) { Text(value, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black); Text(unit, color = Cyan, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0xFF29364A), RoundedCornerShape(50))) { Box(Modifier.fillMaxWidth(.22f).fillMaxHeight().background(Brush.horizontalGradient(listOf(Cyan, Blue)), RoundedCornerShape(50))) }
        }
    }
}
