# F10 DPF Monitor — prototyp Android

Projekt Kotlin + Jetpack Compose z nowoczesnym, ciemnym ekranem dla BMW F10 520d N47 (2010) i telefonu Android 16.

## Co działa w prototypie
- ekran kokpitu DPF w języku polskim;
- prośba o uprawnienia Bluetooth;
- próba automatycznego połączenia po uruchomieniu z wcześniej sparowanym urządzeniem `vLinker BM-Android` przez Bluetooth Classic SPP;
- wysłanie `ATZ` i wyświetlenie odpowiedzi identyfikacyjnej adaptera, jeśli adapter ją zwróci;
- jawne rozróżnienie połączenia z adapterem od połączenia diagnostycznego z ECU.

## Czego jeszcze NIE ma
- nie ma odczytu parametrów BMW DDE ani potwierdzonego statusu regeneracji DPF;
- nie ma automatycznego monitorowania regeneracji w tle ani powiadomień o jej początku/końcu;
- nie jest to gotowy ani przetestowany w samochodzie APK.

Sam fakt połączenia Bluetooth nie daje dostępu do parametrów specyficznych dla BMW. Trzeba dodać i zweryfikować komunikację diagnostyczną DDE dla N47 oraz konkretne identyfikatory/interpretację parametrów. Aplikacja celowo nie zgaduje stanu DPF.

## Budowanie APK
1. Otwórz katalog projektu w aktualnym Android Studio (Android Gradle Plugin 8.7.x).
2. Poczekaj na synchronizację Gradle.
3. Wybierz **Build > Build APK(s)**.
4. Jeśli kompilacja się powiedzie, plik będzie w `app/build/outputs/apk/debug/app-debug.apk`.

Dokumentacja: https://developer.android.com/build/building-cmdline

## Test po instalacji
1. W ustawieniach Androida sparuj `vLinker BM-Android` (PIN często `1234`, jeśli adapter go wymaga).
2. Zamknij BimmerTool/BimmerLink, bo adapter może obsługiwać tylko jedno połączenie naraz.
3. Uruchom prototyp i zaakceptuj uprawnienia Bluetooth.
4. Sprawdź komunikat oraz pole „Ostatnia odpowiedź”.

To test transportu Bluetooth, nie test regeneracji DPF.
